module.exports= {
    JWT_SECRET:"SECRET#123",
    JWT_EXP:"2m",
}